package app.data.repository

import android.content.Context
import app.data.api.ChatApiService
import app.data.api.RetrofitClient
import app.data.model.LoginRequest
import app.data.model.Message
import app.data.model.MessageData
import app.data.model.SendMessageRequest
import app.data.model.TextData
import app.data.offline.AppDatabase
import app.data.offline.NetworkMonitor
import app.data.offline.OfflineCache
import kotlinx.coroutines.flow.first

class ChatRepository(
    private val tokenManager: TokenManager,
    context: Context
) {
    
    private val apiService: ChatApiService = RetrofitClient.apiService
    private val database = AppDatabase.getDatabase(context)
    private val offlineCache = OfflineCache(database)
    private val networkMonitor = NetworkMonitor(context)
    
    suspend fun login(username: String, password: String): Result<String> {
        return try {
            val response = apiService.login(LoginRequest(username, password))
            if (response.isSuccessful && response.body() != null) {
                val token = response.body()!!.string()
                tokenManager.saveToken(token)
                tokenManager.saveCredentials(username, password)
                Result.success(token)
            } else {
                val errorBody = response.errorBody()?.string()
                Result.failure(Exception(errorBody ?: "Login failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun logout(): Result<Unit> {
        return try {
            apiService.logout()
            tokenManager.clearAll()
            offlineCache.clearAll()
            Result.success(Unit)
        } catch (_: Exception) {
            tokenManager.clearAll()
            offlineCache.clearAll()
            Result.success(Unit)
        }
    }
    
    suspend fun getChannels(): Result<List<String>> {
        return try {
            val response = apiService.getChannels()
            if (response.isSuccessful && response.body() != null) {
                val channels = response.body()!!
                offlineCache.saveChannels(channels)
                Result.success(channels)
            } else {
                Result.failure(Exception("Failed to get channels"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun getCachedChannels() = offlineCache.getChannels()
    
    suspend fun getMessages(
        channelName: String,
        limit: Int = 20,
        lastKnownId: Long = 0,
        reverse: Boolean = false
    ): Result<List<Message>> {
        return try {
            val response = apiService.getMessages(channelName, limit, lastKnownId, reverse)
            if (response.isSuccessful && response.body() != null) {
                val messages = response.body()!!
                offlineCache.saveMessages(messages, channelName)
                Result.success(messages)
            } else {
                Result.failure(Exception("Failed to get messages"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun getCachedMessages(channelName: String) = offlineCache.getMessages(channelName)
    
    suspend fun sendMessage(
        username: String,
        text: String,
        channelName: String? = null
    ): Result<String> {
        if (!networkMonitor.isCurrentlyOnline()) {
            return Result.failure(Exception("Нет подключения к интернету"))
        }
        
        return try {
            val token = tokenManager.token.first() ?: return Result.failure(Exception("No token"))
            val request = SendMessageRequest(
                from = username,
                to = channelName,
                data = MessageData(text = TextData(text), image = null)
            )
            val response = apiService.sendMessage(request, token)
            if (response.isSuccessful) {
                Result.success(response.body()?.string() ?: "")
            } else {
                Result.failure(Exception("Failed to send message"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun isOnline(): Boolean = networkMonitor.isCurrentlyOnline()
}
