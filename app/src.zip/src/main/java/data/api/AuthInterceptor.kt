package app.data.api

import android.content.Context
import app.data.repository.TokenManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(
    context: Context
) : Interceptor {
    
    private val tokenManager = TokenManager(context)
    
    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        
        val token = runBlocking {
            tokenManager.token.first()
        }
        
        val requestBuilder = originalRequest.newBuilder()
        
        if (token != null) {
            requestBuilder.header("X-Auth-Token", token)
        }
        
        val request = requestBuilder.build()
        val response = chain.proceed(request)
        
        if (response.code == 401) {
            runBlocking {
                tokenManager.clearAll()
            }
        }
        
        return response
    }
}
