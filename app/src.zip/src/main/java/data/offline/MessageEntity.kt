package app.data.offline

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "messages",
    indices = [Index(value = ["channelName", "id"], unique = true)]
)
data class MessageEntity(
    @PrimaryKey
    val id: String,
    val channelName: String,
    val from: String,
    val text: String?,
    val imageThumb: String?,
    val imageFull: String?,
    val timestamp: Long
)
