package app.ui.chatlist

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.mobdev.R
import app.data.repository.ChatRepository
import app.data.repository.TokenManager
import app.ui.login.LoginActivity
import app.ui.messages.MessagesActivity
import kotlinx.coroutines.launch

@Suppress("DEPRECATION")
class ChatListActivity : AppCompatActivity() {
    
    private val viewModel: ChatListViewModel by viewModels {
        val tokenManager = TokenManager(this)
        val repository = ChatRepository(tokenManager, this)
        ChatListViewModelFactory(repository)
    }
    
    private lateinit var adapter: ChannelAdapter
    private var selectedChannel: String? = null
    private lateinit var tokenManager: TokenManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_list)
        
        supportActionBar?.title = "Чаты"
        
        tokenManager = TokenManager(this)
        
        setupRecyclerView()
        setupLogoutButton()
        observeViewModel()
        
        selectedChannel = savedInstanceState?.getString(SELECTED_CHANNEL_KEY)
    }
    
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
    }
    
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        selectedChannel?.let { outState.putString(SELECTED_CHANNEL_KEY, it) }
    }
    
    @SuppressLint("NotifyDataSetChanged")
    private fun setupRecyclerView() {
        adapter = ChannelAdapter { channel ->
            selectedChannel = channel
            adapter.selectedChannel = channel
            adapter.notifyDataSetChanged()
            openMessagesScreen(channel)
        }
        
        val recyclerView = findViewById<RecyclerView>(R.id.channelsRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }
    
    private fun setupLogoutButton() {
        val logoutButton = findViewById<Button>(R.id.logoutButton)
        logoutButton.setOnClickListener {
            viewModel.logout()
        }
    }
    
    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                adapter.submitList(state.channels)
                
                val progressBar = findViewById<View>(R.id.progressBar)
                progressBar?.visibility = 
                    if (state.isLoading) View.VISIBLE else View.GONE
                
                state.errorMessage?.let { error ->
                    showErrorDialog(error)
                }
                
                if (state.shouldLogout) {
                    viewModel.clearLogoutFlag()
                    startActivity(Intent(this@ChatListActivity, LoginActivity::class.java))
                    finish()
                }
            }
        }
        
        lifecycleScope.launch {
            tokenManager.isLoggedIn.collect { isLoggedIn ->
                if (!isLoggedIn) {
                    startActivity(Intent(this@ChatListActivity, LoginActivity::class.java))
                    finish()
                }
            }
        }
    }
    
    @SuppressLint("NotifyDataSetChanged")
    override fun onResume() {
        super.onResume()
        adapter.selectedChannel = selectedChannel
        adapter.notifyDataSetChanged()
    }
    
    private fun openMessagesScreen(channel: String) {
        startActivity(MessagesActivity.newIntent(this, channel))
    }
    
    @SuppressLint("GestureBackNavigation")
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }
    
    private fun showErrorDialog(message: String) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.error))
            .setMessage(message)
            .setPositiveButton(getString(R.string.ok), null)
            .show()
    }
    
    companion object {
        private const val SELECTED_CHANNEL_KEY = "selected_channel"
        
        fun newIntent(context: Context): Intent {
            return Intent(context, ChatListActivity::class.java)
        }
    }
}
