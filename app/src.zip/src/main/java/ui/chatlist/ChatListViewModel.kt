package app.ui.chatlist

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.data.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatListUiState(
    val isLoading: Boolean = false,
    val channels: List<String> = emptyList(),
    val errorMessage: String? = null,
    val shouldLogout: Boolean = false,
    val isOffline: Boolean = false
)

class ChatListViewModel(
    private val repository: ChatRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(ChatListUiState())
    val uiState: StateFlow<ChatListUiState> = _uiState.asStateFlow()
    
    private var wasOffline = false
    
    init {
        loadChannels()
        observeCachedChannels()
        observeNetworkStatus()
    }
    
    fun loadChannels() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            
            val result = repository.getChannels()
            result.fold(
                onSuccess = { channels ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        channels = channels,
                        isOffline = false
                    )
                },
                onFailure = { _ ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = "Ошибка загрузки каналов",
                        isOffline = !repository.isOnline()
                    )
                }
            )
        }
    }
    
    private fun observeCachedChannels() {
        viewModelScope.launch {
            repository.getCachedChannels().collect { channels ->
                if (channels.isNotEmpty() && _uiState.value.channels.isEmpty()) {
                    _uiState.value = _uiState.value.copy(channels = channels)
                }
            }
        }
    }
    
    private fun observeNetworkStatus() {
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(2000)
                val isOnline = repository.isOnline()
                val currentIsOffline = _uiState.value.isOffline
                
                if (isOnline && currentIsOffline) {
                    loadChannels()
                }
                
                _uiState.value = _uiState.value.copy(isOffline = !isOnline)
            }
        }
    }
    
    fun logout() {
        viewModelScope.launch {
            repository.logout()
            _uiState.value = _uiState.value.copy(shouldLogout = true)
        }
    }
    
    fun clearLogoutFlag() {
        _uiState.value = _uiState.value.copy(shouldLogout = false)
    }
}
