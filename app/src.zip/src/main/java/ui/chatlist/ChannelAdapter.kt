package app.ui.chatlist

import android.R as AndroidR
import app.mobdev.R
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class ChannelAdapter(
    private val onChannelClick: (String) -> Unit
) : ListAdapter<String, ChannelAdapter.ChannelViewHolder>(ChannelDiffCallback()) {
    
    var selectedChannel: String? = null
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel, parent, false)
        return ChannelViewHolder(view, onChannelClick)
    }
    
    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        holder.bind(getItem(position), selectedChannel)
    }
    
    class ChannelViewHolder(
        itemView: View,
        private val onChannelClick: (String) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {
        
        private val textView: TextView = itemView.findViewById(R.id.channelTextView)
        
        fun bind(channel: String, selectedChannel: String?) {
            textView.text = channel
            
            if (channel == selectedChannel) {
                itemView.setBackgroundColor(
                    ContextCompat.getColor(itemView.context, AndroidR.color.holo_blue_light)
                )
            } else {
                itemView.setBackgroundColor(
                    ContextCompat.getColor(itemView.context, AndroidR.color.transparent)
                )
            }
            
            itemView.setOnClickListener { onChannelClick(channel) }
        }
    }
    
    class ChannelDiffCallback : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }
        
        override fun areContentsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }
    }
}
