package app.ui.image

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import coil.load
import app.mobdev.R

class ImageActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_image)
        
        val imageUrl = intent.getStringExtra(EXTRA_IMAGE_URL) ?: return
        
        val imageView = findViewById<android.widget.ImageView>(R.id.imageView)
        imageView.load(imageUrl)
        
        findViewById<android.widget.FrameLayout>(android.R.id.content).setOnClickListener {
            finish()
        }
    }
    
    @SuppressLint("GestureBackNavigation", "MissingSuperCall")
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finish()
    }
    
    companion object {
        const val EXTRA_IMAGE_URL = "image_url"
        
        fun newIntent(context: android.content.Context, imageUrl: String): Intent {
            return Intent(context, ImageActivity::class.java).apply {
                putExtra(EXTRA_IMAGE_URL, imageUrl)
            }
        }
    }
}
