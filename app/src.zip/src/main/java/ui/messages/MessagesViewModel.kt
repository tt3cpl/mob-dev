package app.ui.messages

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.data.model.Message
import app.data.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MessagesUiState(
    val isLoading: Boolean = false,
    val messages: List<Message> = emptyList(),
    val errorMessage: String? = null,
    val messageText: String = "",
    val isSending: Boolean = false,
    val channelName: String = "",
    val isOffline: Boolean = false
)

class MessagesViewModel(
    private val repository: ChatRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(MessagesUiState())
    val uiState: StateFlow<MessagesUiState> = _uiState.asStateFlow()
    
    private var currentLastId: Long = 0
    private var currentChannelName: String = ""
    
    fun setChannel(channelName: String) {
        currentChannelName = channelName
        _uiState.value = _uiState.value.copy(channelName = channelName, messages = emptyList())
        currentLastId = 0
        loadMessages(channelName)
        observeCachedMessages(channelName)
        observeNetworkStatus()
    }

    fun loadMessages(channelName: String, loadMore: Boolean = false) {
        viewModelScope.launch {
            if (!loadMore) {
                _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            }
            
            val result = repository.getMessages(
                channelName = channelName,
                limit = 20,
                lastKnownId = currentLastId,
                reverse = false
            )
            
            result.fold(
                onSuccess = { messages ->
                    val newMessages = if (loadMore) {
                        _uiState.value.messages + messages
                    } else {
                        messages
                    }
                    
                    if (messages.isNotEmpty()) {
                        currentLastId = messages.last().id.toLongOrNull() ?: currentLastId
                    }
                    
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        messages = newMessages,
                        isOffline = false
                    )
                },
                onFailure = {
                    _ ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = "Ошибка загрузки сообщений",
                        isOffline = !repository.isOnline()
                    )
                }
            )
        }
    }
    
    private fun observeNetworkStatus() {
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(2000)
                val isOnline = repository.isOnline()
                val currentIsOffline = _uiState.value.isOffline
                
                if (isOnline && currentIsOffline && currentChannelName.isNotEmpty()) {
                    loadMessages(currentChannelName)
                }
                
                _uiState.value = _uiState.value.copy(isOffline = !isOnline)
            }
        }
    }
    
    fun updateMessageText(text: String) {
        _uiState.value = _uiState.value.copy(messageText = text)
    }
    
    fun sendMessage(username: String) {
        val text = _uiState.value.messageText
        if (text.isBlank()) return
        
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSending = true)
            
            val result = repository.sendMessage(
                username = username,
                text = text,
                channelName = _uiState.value.channelName
            )
            
            result.fold(
                onSuccess = {
                    _uiState.value = _uiState.value.copy(
                        isSending = false,
                        messageText = ""
                    )
                    loadMessages(_uiState.value.channelName)
                },
                onFailure = { _ ->
                    _uiState.value = _uiState.value.copy(
                        isSending = false,
                        errorMessage = "Ошибка отправки"
                    )
                }
            )
        }
    }
    
    fun loadMoreMessages() {
        if (!_uiState.value.isLoading) {
            loadMessages(_uiState.value.channelName, loadMore = true)
        }
    }
    
    private fun observeCachedMessages(channelName: String) {
        viewModelScope.launch {
            repository.getCachedMessages(channelName).collect { messages ->
                if (messages.isNotEmpty() && _uiState.value.messages.isEmpty()) {
                    _uiState.value = _uiState.value.copy(messages = messages)
                }
            }
        }
    }
}
