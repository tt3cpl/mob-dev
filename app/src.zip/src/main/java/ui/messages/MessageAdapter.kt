package app.ui.messages

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import app.mobdev.R
import app.data.model.Message

class MessageAdapter(
    private val onImageClick: (String) -> Unit
) : ListAdapter<Message, MessageAdapter.MessageViewHolder>(MessageDiffCallback()) {
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view, onImageClick)
    }
    
    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
    
    class MessageViewHolder(
        itemView: View,
        private val onImageClick: (String) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {
        
        private val fromTextView: TextView = itemView.findViewById(R.id.fromTextView)
        private val textTextView: TextView = itemView.findViewById(R.id.textTextView)
        private val imageView: ImageView = itemView.findViewById(R.id.imageView)
        
        fun bind(message: Message) {
            fromTextView.text = message.from
            
            message.data.text?.let { textData ->
                textTextView.text = textData.text
                textTextView.visibility = View.VISIBLE
            } ?: run {
                textTextView.visibility = View.GONE
            }
            
            message.data.image?.let { imageData ->
                if (imageData.link != null) {
                    val thumbUrl = "https://faerytea.name/thumb/${imageData.link}"
                    imageView.load(thumbUrl)
                    imageView.visibility = View.VISIBLE
                    imageView.setOnClickListener {
                        val fullUrl = "https://faerytea.name/img/${imageData.link}"
                        onImageClick(fullUrl)
                    }
                } else {
                    imageView.visibility = View.GONE
                }
            } ?: run {
                imageView.visibility = View.GONE
            }
        }
    }
    
    class MessageDiffCallback : DiffUtil.ItemCallback<Message>() {
        override fun areItemsTheSame(oldItem: Message, newItem: Message): Boolean {
            return oldItem.id == newItem.id
        }
        
        override fun areContentsTheSame(oldItem: Message, newItem: Message): Boolean {
            return oldItem == newItem
        }
    }
}
