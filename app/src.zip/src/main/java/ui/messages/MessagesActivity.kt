package app.ui.messages

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.mobdev.R
import app.data.repository.ChatRepository
import app.data.repository.TokenManager
import app.ui.image.ImageActivity
import app.ui.login.LoginActivity
import kotlinx.coroutines.launch

class MessagesActivity : AppCompatActivity() {
    
    private val viewModel: MessagesViewModel by viewModels {
        val tokenManager = TokenManager(this)
        val repository = ChatRepository(tokenManager, this)
        MessagesViewModelFactory(repository)
    }
    
    private lateinit var adapter: MessageAdapter
    private lateinit var username: String
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_messages)
        
        val channelName = intent.getStringExtra(EXTRA_CHANNEL_NAME) ?: return
        
        setupRecyclerView()
        setupViews()
        observeViewModel()
        
        viewModel.setChannel(channelName)
    }
    
    private fun setupRecyclerView() {
        adapter = MessageAdapter { imageUrl ->
            startActivity(ImageActivity.newIntent(this, imageUrl))
        }
        
        val recyclerView = findViewById<RecyclerView>(R.id.messagesRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        
        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                if (!recyclerView.canScrollVertically(1)) {
                    viewModel.loadMoreMessages()
                }
            }
        })
    }
    
    private fun setupViews() {
        val backButton = findViewById<android.widget.Button>(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }
        
        val messageEditText = findViewById<android.widget.EditText>(R.id.messageEditText)
        val sendButton = findViewById<android.widget.Button>(R.id.sendButton)
        
        sendButton.setOnClickListener {
            val text = messageEditText.text.toString()
            if (text.isNotBlank()) {
                viewModel.updateMessageText(text)
                viewModel.sendMessage(username)
                messageEditText.text.clear()
            }
        }
    }
    
    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                val previousSize = adapter.currentList.size
                adapter.submitList(state.messages)
                
                val recyclerView = findViewById<RecyclerView>(R.id.messagesRecyclerView)
                if (state.messages.size > previousSize) {
                    recyclerView.scrollToPosition(state.messages.size - 1)
                }
                
                findViewById<android.widget.ProgressBar>(R.id.progressBar).visibility = 
                    if (state.isLoading) android.view.View.VISIBLE else android.view.View.GONE
                
                findViewById<android.widget.Button>(R.id.sendButton).isEnabled = 
                    !state.isSending && !state.isOffline
            }
        }
        
        lifecycleScope.launch {
            val tokenManager = TokenManager(this@MessagesActivity)
            tokenManager.credentials.collect { (user, _) ->
                username = user ?: ""
            }
        }
        
        lifecycleScope.launch {
            val tokenManager = TokenManager(this@MessagesActivity)
            tokenManager.isLoggedIn.collect { isLoggedIn ->
                if (!isLoggedIn) {
                    startActivity(Intent(this@MessagesActivity, LoginActivity::class.java))
                    finish()
                }
            }
        }
    }

    companion object {
        const val EXTRA_CHANNEL_NAME = "channel_name"

        fun newIntent(context: android.content.Context, channelName: String): Intent {
            return Intent(context, MessagesActivity::class.java).apply {
                putExtra(EXTRA_CHANNEL_NAME, channelName)
            }
        }
    }
}
