package app.ui.messages

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.mobdev.R
import app.data.repository.ChatRepository
import app.data.repository.TokenManager
import app.ui.image.ImageActivity
import app.ui.login.LoginActivity
import kotlinx.coroutines.launch

class MessagesFragment : Fragment() {
    
    private val viewModel: MessagesViewModel by viewModels {
        val tokenManager = TokenManager(requireContext())
        val repository = ChatRepository(tokenManager, requireContext())
        MessagesViewModelFactory(repository)
    }
    
    private lateinit var adapter: MessageAdapter
    private lateinit var username: String
    private var channelName: String? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        channelName = arguments?.getString(ARG_CHANNEL_NAME)
    }
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_messages, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupRecyclerView()
        setupViews()
        observeViewModel()
        
        channelName?.let { viewModel.setChannel(it) }
    }

    private fun setupRecyclerView() {
        adapter = MessageAdapter { imageUrl ->
            startActivity(ImageActivity.newIntent(requireContext(), imageUrl))
        }
        
        val recyclerView = view?.findViewById<RecyclerView>(R.id.messagesRecyclerView)
        recyclerView?.layoutManager = LinearLayoutManager(requireContext())
        recyclerView?.adapter = adapter
        
        recyclerView?.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                if (!recyclerView.canScrollVertically(1)) {
                    viewModel.loadMoreMessages()
                }
            }
        })
    }
    
    private fun setupViews() {
        val messageEditText = view?.findViewById<android.widget.EditText>(R.id.messageEditText)
        val sendButton = view?.findViewById<android.widget.Button>(R.id.sendButton)
        
        sendButton?.setOnClickListener {
            val text = messageEditText?.text?.toString() ?: ""
            if (text.isNotBlank()) {
                viewModel.updateMessageText(text)
                viewModel.sendMessage(username)
                messageEditText?.text?.clear()
            }
        }
    }
    
    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                val previousSize = adapter.currentList.size
                adapter.submitList(state.messages)
                
                val recyclerView = view?.findViewById<RecyclerView>(R.id.messagesRecyclerView)
                if (state.messages.size > previousSize && recyclerView != null) {
                    recyclerView.scrollToPosition(state.messages.size - 1)
                }
                
                view?.findViewById<android.widget.ProgressBar>(R.id.progressBar)?.visibility = 
                    if (state.isLoading) View.VISIBLE else View.GONE
                
                view?.findViewById<android.widget.Button>(R.id.sendButton)?.isEnabled = 
                    !state.isSending
            }
        }
        
        lifecycleScope.launch {
            val tokenManager = TokenManager(requireContext())
            tokenManager.credentials.collect { (user, _) ->
                username = user ?: ""
            }
        }
        
        lifecycleScope.launch {
            val tokenManager = TokenManager(requireContext())
            tokenManager.isLoggedIn.collect { isLoggedIn ->
                if (!isLoggedIn) {
                    requireActivity().startActivity(Intent(requireContext(), LoginActivity::class.java))
                    requireActivity().finish()
                }
            }
        }
    }
    
    companion object {
        private const val ARG_CHANNEL_NAME = "channel_name"

    }
}
